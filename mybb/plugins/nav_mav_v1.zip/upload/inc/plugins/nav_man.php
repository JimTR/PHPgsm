<?php
/*
 * nav-man.php
 * 
 * Copyright 2020 Jim Richardson <jim@noideersoftware.co.uk>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * 
 */
  if(!defined("IN_MYBB"))
{
    die("You Cannot Access This File Directly. Please Make Sure IN_MYBB Is Defined.");
}
if(!defined("PLUGINLIBRARY"))
{
    define("PLUGINLIBRARY", MYBB_ROOT."inc/plugins/pluginlibrary.php");
}

// hooks 
$plugins->add_hook('global_end','global_end');
$plugins->add_hook('page_start','ge_end');
$plugins->add_hook('forumdisplay_end','po_end');
$plugins->add_hook('index_start','po_end');
$plugins->add_hook('showthread_start','po_end');
$plugins->add_hook('portal_start','po_end');
$plugins->add_hook('online_start','po_end');
$plugins->add_hook('modcp_start','po_end');
$plugins->add_hook('calendar_start','po_end');
$plugins->add_hook('search_start','po_end');
$plugins->add_hook('search_results_start','po_end');
$plugins->add_hook('memberlist_end','po_end');
$plugins->add_hook('member_profile_start','po_end');
$plugins->add_hook('usercp_start','po_end');
$plugins->add_hook('polls_start','po_end');
$plugins->add_hook('private_start','po_end');
$plugins->add_hook('reputation_start','po_end');
$plugins->add_hook('misc_start','po_end');
$plugins->add_hook('editpost_start','po_end');
$plugins->add_hook('contact_start','po_end');
$plugins->add_hook('stats_start','po_end');
// end hooks


function nav_man_info() {
/*
 * 
 * name: nav-man_info
 * sends plugin info back to mybb
 * 
 * 
 */
	
	$codename = str_replace('.php', '', basename(__FILE__));
	return array(
		"name"			=> 'Navigation Manager ('.$codename.')',
		"description"	=> "Control the navigation system",
		"website"		=> "https://mybb.noideersoftware.co.uk",
		"author"			=> 'JimR',
		"authorsite"	=> "https://noideersoftware.co.uk/",
		"version"		=> '1.01a',
		"guid" 			=> '',
		"codename"	=> $codename,
		"compatibility" => '18*'
	);
	
}

function nav_man_install()
{
	  if(!file_exists(PLUGINLIBRARY))
    {
        flash_message("The selected plugin could not be installed because <a href=\"http://mods.mybb.com/view/pluginlibrary\">PluginLibrary</a> is missing.", "error");
        admin_redirect("index.php?module=config-plugins");
    }

	
       global $PL;
    $PL or require_once PLUGINLIBRARY;

   
    if($PL->version < 11)
    {
        flash_message("The selected plugin could not be installed because <a href=\"http://mods.mybb.com/view/pluginlibrary\">PluginLibrary</a> is too old.", "error");
        admin_redirect("index.php?module=config-plugins");
    }
    $codename = str_replace('.php', '', basename(__FILE__));
	
    $file=$codename.'.txt';
    if(!is_file($file)){
    $contents = time();           // Some simple example content. like mods 
    file_put_contents($file, $contents);     // Save our content to the file.
}

}

function nav_man_activate()
{
	 global $PL, $mybb;
    $PL or require_once PLUGINLIBRARY;
	  
    $PL->settings("nav_man", // group name and settings prefix
                  "Navigation Manager",
                  "Settings for the Navigation Manager plugin.",
                  array(
                      "home" => array(
                          "title" => "Home Title",
                          "description" => "enter text to displayed for the home link",
                          "optionscode" => "text",
                          "value" => "Home",
                          ),
                      "script" => array(
                          "title" => "Home Script",
                          "description" => "add home script here<br><b>example : portal.php</b><br>if blank this will link to the web server defined index page, also if set to index.php functionally is switched off with the exception of renaming the home page navigation entry",
                          "optionscode" => "text",
                          "value" => "",
                          ),
                      "forums" => array(
                          "title" => "Hidden Forums",
                          "description" => "This is for use with xthreads hidden forum function<br><b>leave blank</b> if you do not use xthreads.<br>if using xthreads  this function will this will shorten the the navigation to home->forum name",
                          "optionscode" => "text",
                          "value" => '',
                          ),
                      "forum" => array(
                          "title" => "Forum Area Name",
                          "description" => "This setting will display on the navigation as the link text for index.php if you are using a different script as your home page",
                          "optionscode" => "text",
                          "value" =>'',
                          ),
                      "gis" => array(
                          "title" => "Disable Navigation on home page",
                          "description" => "Disable navigation on home page ",
                          "optionscode" => "yesno",
                          "value" => 0,
                          ),
                         "files" => array(
                          "title" => "Add scripts that will not appear under forums.",
                          "description" => "Add scripts that will <b>NOT</b> have the forum link added to the navigation. seperate each script with a comma.<br>This has no bearing if you use index.php as your home page ",
                          "optionscode" => "text",
                          "value" => "",
                          ),   
                      )
                  // , true /* optional,  prints a language file */
        );
	}

function nav_man_uninstall()
{
    global $PL;
    $PL or require_once PLUGINLIBRARY;
   
    $PL->settings_delete("nav_man"
                         // , true /* optional, multiple groups */
        );
	}

function global_end() {
global $output,$navbits,$mybb;
		   /* over rides mybb global navigation
		    * relies on no core edits to alter THIS_SCRIPT
		    * if core edit are made to THIS_SCRIPT the plugin will fail 
		    */ 
		     preg_match('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $mybb->settings['ge_script'], $match);
			$tmp = explode(' ',htaccess());
			if (isset($match[0])) {
				if (empty($mybb->settings['nav_man_home'])) {
					// this code should never execute unless the user does not add a home page title
					$mybb->settings['nav_man_home'] = $mybb->settings['bbname']; // set default
					
				}
				$navbits[0]['name']=$mybb->settings['nav_man_home'] ;
			    $navbits[0]['url'] = $mybb->settings['nav_man_script']; // if empty will just use the webserver directive if set this could be off site
			}
			else {
				
				if (empty($mybb->settings['nav_man_home'])) {
						$mybb->settings['nav_man_home'] = $mybb->settings['bbname'];
						}
						
						if (empty($mybb->settings['nav_man_script'])) {
							$mybb->settings['nav_man_script'] = $mybb->settings['bburl'].'/'.$tmp[1];
						}
				 $navbits[0]['name']=$mybb->settings['nav_man_home'] ; // add link text
			     $navbits[0]['url'] = $mybb->settings['nav_man_script']; // get around index.php appended & add a url if empty
			     $full_url = $mybb->settings['nav_man_script']; 
			}
			//echo $full_url.'<br>';
			if (isset($mybb->settings['nav_man_script'])) {
				//echo 'setting is set<br>';
				switch (THIS_SCRIPT) {
					// forum related ?
					case 'forumdisplay.php':
					case 'showthread.php':
					case 'index.php':
						if ($mybb->settings['bburl'].'/index.php' == $full_url) {break;}
						add_breadcrumb( $mybb->settings['nav_man_forum'], $mybb->settings['bburl'].'/index.php');
						
						break;
					default:
						// maybe add group for certain files ?
						//echo 'This script = '.THIS_SCRIPT;
						//print_r($mybb->settings);
						 $modules = explode(',',$mybb->settings['nav_man_files']);
						 //echo $mybb->settings['nav_man_files'].' - '.print_r($modules,true);
						 $key = array_search(THIS_SCRIPT, $modules);
						$key = $modules[$key];
						if (THIS_SCRIPT ==  $key){
							// check if  not under forums
							//add_breadcrumb( $mybb->settings['nav_man_forum'], $mybb->settings['bburl'].'/index.php');
							
							}
					else {
						add_breadcrumb( $mybb->settings['nav_man_forum'], $mybb->settings['bburl'].'/index.php');
					}			
				}
								
			}
}


function po_end() {
/*
 * 
 * name: po_end
 * alters the navigation as per the plugin settings
 * @return - nothing
 * 
 */	
	 global $navbits,$mybb,$parentlistexploded,$fid;
	
	  $homeurl = parse_url($mybb->settings['ge_script']);
	  if(!isset ($homeurl['host'])) {
		  $look = $mybb->settings['bburl'].'/'.$mybb->settings['ge_script'];
	  }
	  else {
		  $look = $mybb->settings['ge_script'];
	  }
	  
	  $ref = $mybb->settings['bburl'].'/'.basename($_SERVER['SCRIPT_NAME']);
	  
		   	 if($look === $ref ) {
					// Match home page delete any navbits that have been added
						for ($i = 1; $i < count($navbits); $i++) {
							unset($navbits[$i]);
						}
					if ($mybb->settings['ge_dis'] )	{
						// delete the whole navigation 
						unset($navbits[0]);
					}
		  				
				}
			else {
					
			$foruminfo = get_forum($fid);
			$parentlistexploded = explode(',',$foruminfo['parentlist']);
			if(!empty($parentlistexploded[0])){ 
		  	  $run = explode(',',$mybb->settings['ge_forums']);
		       
				if(count(array_intersect($parentlistexploded, $run)) > 0) {
					unset($navbits[1]);
					// this is a direct link for xthreads 
					$navbits  = array_values($navbits); // rebuild the array
				}
			}

	     return;
	 }
 }
 
/*
 * 
 * name: htaccess
 * @param
 * @return
 * 
 */
 function htaccess() {
	 
	$tmp = file_get_contents('.htaccess');
	$htaccess= explode(PHP_EOL,$tmp);
	$m_array = preg_grep('/^DirectoryIndex\s.*/', $htaccess);
	$m_array = array_values($m_array);
	//print_r($m_array);
	if (isset($m_array[0])) {
		return $m_array[0];
	}
}
?>
<?php
/*
	Language file for MyBB-PageManager plugin for MyBB 1.8
	Language: english
	Copyright © 2017 Svepu
	Last change: 2017-02-10
*/

$l['pagemanager_page_disabled_redirect']='Sorry, this page is temporary disabled. - You will be redirected to Index page.';
$l['pagemanager_online']='Viewing <a href="misc.php?page={1}">{2}</a>';
$l['pagemanager_page_error_only_mobile']='Sorry, this page is visible on mobile devices only.';
$l['pagemanager_page_error_only_desktop']='Sorry, this page is visible on desktop devices only.';

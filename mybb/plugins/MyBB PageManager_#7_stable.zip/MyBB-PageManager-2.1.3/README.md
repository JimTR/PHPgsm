[![Minimum PHP Version](https://img.shields.io/badge/php-%20>%3D5.4%20-blue.svg?style=flat-square)](https://php.net/)

# MyBB-PageManager
**A fully to MyBB 1.8 adapted version of Sebastian Wunderlichs plugin "PageManager" with some new features.**

**Installation:**
* Download and unzip plugin package
* Copy content from "UPLOAD" folder to the forum root on server
* Install&Activate the plugn in ACP
* DONE!

*Check the PageManager option in ACP configuration after installation*

----------------------------------------
**Full Update:**
* Download & unzip new plugin package
* Uninstall plugin in ACP
* Copy content from "UPLOAD" folder to the forum root on server - rewrite the older files
* Install&Activate the plugn in ACP
* DONE!

*Check the PageManager option in ACP configuration after updating*

-----------------------------------------
**Enhanced Update:**
* Download & unzip new plugin package
* Deactivate plugin in ACP
* Copy content from "UPLOAD" folder to the forum root on server - rewrite the older files
* Activate the plugn in ACP
* DONE!

*Check the PageManager option in ACP configuration after updating*

-----------------------------------------
**Simple Update:**
* Download & unzip new plugin package
* Copy content from "UPLOAD" folder to the forum root on server - rewrite the older files
* DONE!

*Check the PageManager option in ACP configuration after updating*

---------------------------------------


